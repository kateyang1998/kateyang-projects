﻿/*
 * Name of project: KYangQGame
 * 
 * Purpose of project: to complete a Q Game
 * 
 * Revision history:
 *      created by Kate Yang, Nov 1, 2023
 *      re-edited by Kate Yang, Nov 16, 2023
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KYangQGame
{
    // Control panel
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Design button
        private void btnDesign_Click(object sender, EventArgs e)
        {
            // Open design form
            DesignForm designForm = new DesignForm();
            designForm.Show();
        }

        // Play button
        private void btnPlay_Click(object sender, EventArgs e)
        {
            // Open play form
            PlayForm playForm = new PlayForm();
            playForm.Show();
        }

        // Exit button
        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the control panel
            this.Close();
        }
    }
}
