﻿/*
 * Name of project: KYangQGame
 * 
 * Purpose of project: to complete a Q Game
 * 
 * Revision history:
 *      created by Kate Yang, Nov 1, 2023
 *      re-edited by Kate Yang, Nov 16, 2023
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KYangQGame
{
    public partial class PlayForm : Form
    {
        // Declare the images, and size of cell
        Image empty = Properties.Resources.none_sign;
        Image wall = Properties.Resources.brick_wall;
        Image redDoor = Properties.Resources.rdoor;
        Image greenDoor = Properties.Resources.gdoor;
        Image redBox = Properties.Resources.rbox;
        Image greenBox = Properties.Resources.gbox;

        // Declare the grid of picturebox, the picturebox of selected box, and the filePath for saving design
        PictureBox[,] grid;
        PictureBox selectedBox;
        int cellSize = 50;
        int gridPadding = 180;
        string filePath;

        public PlayForm()
        {
            InitializeComponent();
        }

        // Method to initialize the score
        private void InitializeScore()
        {
            // Initialize the moves and boxes to 0
            txtMoves.Text = "0";
            int moves = int.Parse(txtMoves.Text);
            txtBoxes.Text = "0";
            int boxes = int.Parse(txtBoxes.Text);

            // Loop in the grid
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    // Check if the cell is a box
                    if (grid[i, j].Tag == "4" || grid[i, j].Tag == "5")
                    {
                        // Increment the number of boxes
                        boxes++;
                    }
                }
            }
            // Display boxes number in textbox
            txtBoxes.Text = boxes.ToString();
        }

        // Method to reset the form
        private void ResetForm()
        {
            // Reset the grid if there is an existing level
            if (grid != null)
            {
                foreach (PictureBox cell in grid)
                {
                    // Remove the existing grid and start from scratch based on the loaded file
                    this.Controls.Remove(cell);
                    cell.Dispose();
                    txtBoxes.Clear();
                    txtMoves.Clear();
                }
            }
        }

        // Method to move boxes
        private void MoveBox(PictureBox box, int dx, int dy) 
        {
            // Get the current row and column of the box
            int row = (box.Location.Y - gridPadding) / cellSize;
            int column = (box.Location.X - gridPadding) / cellSize;

            // Get the next row and column of the box
            int nextRow = row + dy;
            int nextColumn = column + dx;

            // Check if the next row and column are within the grid bounds
            if (nextRow >= 0 && nextRow < grid.GetLength(0) && nextColumn >= 0 && nextColumn < grid.GetLength(1))
            {
                // Get the next cell
                PictureBox nextCell = grid[nextRow, nextColumn];
                selectedBox = box;
                
                switch (nextCell.Tag)
                {
                    case "1":
                        break; // Stop movement when hits wall
                    case "2":
                        if (box.Tag == "4")
                        {
                            box.Image = null;
                            box.Tag = "0";
                            int boxes = int.Parse(txtBoxes.Text);
                            boxes--;
                            txtBoxes.Text = boxes.ToString();

                            if (boxes == 0)
                            {
                                // Show game over message
                                MessageBox.Show("Level completed!", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Reset the form
                                ResetForm();
                            }
                        }
                        break;
                    case "3":
                        if (box.Tag == "5")
                        {
                            box.Image = null;
                            box.Tag = "0";
                            int boxes = int.Parse(txtBoxes.Text);
                            boxes--;
                            txtBoxes.Text = boxes.ToString();

                            if (boxes == 0)
                            {
                                // Show game over message
                                MessageBox.Show("Level completed!", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Reset the form
                                ResetForm();
                            }
                        }
                        break;
                    case "0":
                        // Move the box to the next cell, switch box location
                        var previousLocation = box.Location;
                        box.Location = nextCell.Location;
                        nextCell.Location = previousLocation;
                        // Update the grid and score
                        grid[row, column] = nextCell;
                        grid[nextRow, nextColumn] = box;
                        int moves = int.Parse(txtMoves.Text);
                        moves++;
                        txtMoves.Text = moves.ToString();
                        break;
                }
            }
        }

        // Load game tab
        private void loadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text files (*.txt)|*.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                filePath = ofd.FileName;  
            }
            else
            {
                return;
            }

            using (StreamReader sr = new StreamReader(filePath))
            {
                // Get the number of rows and columns from the first line of the file
                string line = sr.ReadLine();
                string[] dimensions = line.Split(' ');
                int rows = int.Parse(dimensions[0]);
                int columns = int.Parse(dimensions[1]);

                // Reset the form if there is an existing grid
                ResetForm();

                // Create a new grid based on the loaded file
                grid = new PictureBox[rows, columns];

                // Loop in the grid
                for (int i = 0; i < grid.GetLength(0); i++)
                {
                    // Read the next line from the file
                    line = sr.ReadLine();

                    for (int j = 0; j < grid.GetLength(1); j++)
                    {
                        // Create picture box for the grid
                        PictureBox cell = new PictureBox();

                        // Set the cells of the grid (create pictureboxes)
                        cell.Name = "cell" + i + j;
                        cell.Size = new Size(cellSize, cellSize);
                        cell.Location = new Point(gridPadding + j * cellSize, gridPadding + i * cellSize);
                        cell.BorderStyle = BorderStyle.Fixed3D;
                        cell.SizeMode = PictureBoxSizeMode.StretchImage;
                        cell.BackColor = Color.LightYellow;
                        cell.Tag = "";

                        // Assign the image and tag according to the file data
                        switch (line[j])
                        {
                            case '1':
                                cell.Image = wall;
                                cell.Tag = "1";
                                break;
                            case '2':
                                cell.Image = redDoor;
                                cell.Tag = "2";
                                break;
                            case '3':
                                cell.Image = greenDoor;
                                cell.Tag = "3";
                                break;
                            case '4':
                                cell.Image = redBox;
                                cell.Tag = "4";
                                break;
                            case '5':
                                cell.Image = greenBox;
                                cell.Tag = "5";
                                break;
                            case '0':
                                cell.Image = null;
                                cell.Tag = "0";
                                break;
                        }

                        // Add the picture box to the grid and the form
                        grid[i, j] = cell;
                        this.Controls.Add(cell);

                        // Add a click event handler for the cells
                        cell.Click += gridCell_Click;
                    }
                }
            }
            
            // Use method to initialize score
            InitializeScore();
        }

        // Enable the grid cell to be clicked
        private void gridCell_Click(object sender, EventArgs e)
        {
            PictureBox cell = sender as PictureBox;

            if (cell == null)
            {
                return;
            }

            if (cell.Tag == "4" || cell.Tag == "5")
            {
                if (selectedBox != null)
                {
                    // Switch the selection, remove border from the previous selected box picturebox
                    selectedBox.BorderStyle = BorderStyle.Fixed3D;
                }

                // Add border to the current selected box
                cell.BorderStyle = BorderStyle.FixedSingle;

                // Assign the clicked box to the current selected box
                selectedBox = cell;
            }
        }

        // Close tab
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Close the play form
            this.Close();
        }

        // Up button
        private void btnUp_Click(object sender, EventArgs e)
        {
            // Check if any box is selected
            if (selectedBox != null)
            {
                // Move the box to the up until it hits another box or wall or door
                MoveBox(selectedBox, 0, -1);
            }
            else
            {
                // Display notification
                MessageBox.Show("Please select a box.", "Select a Box", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Left button
        private void btnLeft_Click(object sender, EventArgs e)
        {
            // Check if any box is selected
            if (selectedBox != null)
            {
                // Move the box to the left until it hits another box or wall or door
                MoveBox(selectedBox, -1, 0);
            }
            else
            {
                // Display notification
                MessageBox.Show("Please select a box.", "Select a Box", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Down button
        private void btnDown_Click(object sender, EventArgs e)
        {
            // Check if any box is selected
            if (selectedBox != null)
            {
                // Move the box to the down until it hits another box or wall or door
                MoveBox(selectedBox, 0, 1);
            }
            else
            {
                // Display notification
                MessageBox.Show("Please select a box.", "Select a Box", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Right button
        private void btnRight_Click(object sender, EventArgs e)
        {
            // Check if any box is selected
            if (selectedBox != null)
            {
                // Move the box to the right until it hits another box or wall or door
                MoveBox(selectedBox, 1, 0);
            }
            else
            {
                // Display notification
                MessageBox.Show("Please select a box.", "Select a Box", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
