﻿/*
 * Name of project: KYangQGame
 * 
 * Purpose of project: to complete a Q Game
 * 
 * Revision history:
 *      created by Kate Yang, Nov 1, 2023
 *      re-edited by Kate Yang, Nov 16, 2023
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KYangQGame
{
    // Design form
    public partial class DesignForm : Form
    {
        // Declare the max number of rows and columns, and size of cell
        int maxRows = 10;
        int maxColumns = 10;
        int cellSize = 50;

        // Declare the grid of picturebox, the picturebox of selected tools, and the filePath for saving design
        PictureBox[,] grid;
        PictureBox selectedTool;
        string filePath;

        public DesignForm()
        {
            InitializeComponent();
            // Initial setting when the form loaded
            grid = null;
            selectedTool = null;
            filePath = "";
        }

        // Generate button
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            int rows = int.Parse(txtRows.Text);
            int columns = int.Parse(txtColumns.Text);

            // Validate if the input is valid
            if (rows < 1 || rows > maxRows || columns < 1 || columns > maxColumns)
            {
                // Display error message
                MessageBox.Show("Please enter the integer between 1 and 10 for rows and columns", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Clear row and column input boxes
                txtRows.Clear();
                txtColumns.Clear();
                
                return;
            }
            else
            {
                txtRows.Clear();
                txtColumns.Clear();
            }

            // Reset the grid when there is a design existing
            if (grid != null) 
            {
                // Display confirm message
                DialogResult result = MessageBox.Show("Do you want to reset level? The current level will be cleared if yes.", "Reset Level", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.No)
                {
                    return;
                }
                else
                {
                    foreach (PictureBox cell in grid)
                    {
                        // Clear the existing grid and start from scratch based on the input of row and column
                        this.Controls.Remove(cell);
                        cell.Dispose();
                    }
                }
            }

            // Generate new grid based on inputs of rows and columns
            grid = new PictureBox[rows, columns];

            // Loop in the grid
            for (int i = 0; i < rows; i++) 
            { 
                for (int j = 0; j < columns; j++) 
                { 
                    // Create picture box for the grid
                    PictureBox cell = new PictureBox();

                    // Set the cells of the grid (create pictureboxes)
                    cell.Name = "cell" + i + j;
                    cell.Size = new Size(cellSize, cellSize);
                    cell.Location = new Point(450 + j * cellSize, 180 + i * cellSize);
                    cell.BorderStyle = BorderStyle.Fixed3D;
                    cell.SizeMode = PictureBoxSizeMode.StretchImage;
                    cell.BackColor = Color.LightYellow;
                    // Type of tools
                    cell.Tag = "";

                    // Add cells to the grid
                    grid[i, j] = cell;
                    this.Controls.Add(cell);

                    // Add a click event handler for the cells
                    cell.Click += gridCell_Click;
                }
            }
        }

        // Grid cells - assign tools
        private void gridCell_Click(object sender, EventArgs e)
        {
            PictureBox cell = sender as PictureBox;

            if (cell == null) 
            {
                return;
            }

            // Check if any tool is selected
            if (selectedTool != null)
            {
                // Name "none" image's tag "0"
                if (selectedTool.Tag == "0")
                {
                    // Display nothing when selectedTool is "0"
                    cell.Image = null;
                    // Assign the type of tool to the clicked cell
                    cell.Tag = selectedTool.Tag;
                }
                else
                {
                    // Display the selected tool image to the clicked cell
                    cell.Image = selectedTool.Image;
                    // Assign the type of tool to the clicked cell
                    cell.Tag = selectedTool.Tag;
                }
            }
        }

        // Tools - enable to click the tool pictureboxes
        private void OnClick(object sender, EventArgs e)
        {
            PictureBox tool = sender as PictureBox;

            if (tool == null) 
            {
                return;
            }

            // Check if any tool is selected
            if (selectedTool != null)
            {
                // Switch the selection, add border to only the current selected tool picturebox
                selectedTool.BorderStyle = BorderStyle.Fixed3D;
            }

            // Add border to the selected tool picturebox
            tool.BorderStyle = BorderStyle.FixedSingle;

            // Assign the clicked tool to the current selected tool
            selectedTool = tool;
        }

        // Save tab
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Check if there is grid existing
            if (grid != null)
            {
                // Check if the file path is empty
                if (filePath == "")
                {
                    // Get file path
                    SaveFileDialog sfd = new SaveFileDialog();
                    // Set the file format to save as .txt
                    sfd.Filter = "Text files (*.txt)|*.txt";

                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        filePath = sfd.FileName;
                    }
                    else
                    {
                        return;
                    }
                }

                // Save(Write) the data to the file
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    // Write row and column number of the grid
                    sw.WriteLine(grid.GetLength(0) + " " + grid.GetLength(1));

                    // Loop in the grid
                    for (int i = 0; i < grid.GetLength(0); i++)
                    {
                        for (int j = 0; j < grid.GetLength(1); j++)
                        {
                            // Record to tag for each clicked cells in the file
                            sw.Write(grid[i, j].Tag.ToString());
                        }

                        // Start a new line after each row
                        sw.WriteLine();
                    }
                }

                // Count the number of walls, doors, and boxes in the grid
                int walls = 0;
                int doors = 0;
                int boxes = 0;

                // Loop in the grid
                foreach (PictureBox cell in grid)
                {
                    // Name "wall" image's tag "1"
                    if (cell.Tag.ToString() == "1")
                    {
                        walls++;
                    }

                    // Name "red door" image's tag "2", "green door" image's tag "3"
                    if (cell.Tag.ToString() == "2" || cell.Tag.ToString() == "3")
                    {
                        doors++;
                    }

                    // Name "red box" image's tag "4", "green box" image's tag "5"
                    if (cell.Tag.ToString() == "4" || cell.Tag.ToString() == "5")
                    {
                        boxes++;
                    }
                }

                // Display saved successfully message
                MessageBox.Show($"The level design file saved successfully.\nWalls: {walls}\nDoors: {doors}\nBoxes: {boxes}", "Save File", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Close tab
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Close the design form
            this.Close();
        }

        private void DesignForm_Load(object sender, EventArgs e)
        {
            // Nothing in here
        }
    }
}
