﻿namespace KYangQGame
{
    partial class DesignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblRows = new System.Windows.Forms.Label();
            this.lblColumns = new System.Windows.Forms.Label();
            this.txtColumns = new System.Windows.Forms.TextBox();
            this.txtRows = new System.Windows.Forms.TextBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.lblTools = new System.Windows.Forms.Label();
            this.lblGreenBox = new System.Windows.Forms.Label();
            this.lblRedBox = new System.Windows.Forms.Label();
            this.lblGreenDoor = new System.Windows.Forms.Label();
            this.lblRedDoor = new System.Windows.Forms.Label();
            this.lblWall = new System.Windows.Forms.Label();
            this.lblNone = new System.Windows.Forms.Label();
            this.pictureBoxGB = new System.Windows.Forms.PictureBox();
            this.pictureBoxWall = new System.Windows.Forms.PictureBox();
            this.pictureBoxRB = new System.Windows.Forms.PictureBox();
            this.pictureBoxGD = new System.Windows.Forms.PictureBox();
            this.pictureBoxRD = new System.Windows.Forms.PictureBox();
            this.pictureBoxNone = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNone)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(967, 45);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(78, 41);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(218, 46);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(218, 46);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.ForeColor = System.Drawing.Color.White;
            this.lblRows.Location = new System.Drawing.Point(12, 66);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(91, 31);
            this.lblRows.TabIndex = 1;
            this.lblRows.Text = "Rows:";
            // 
            // lblColumns
            // 
            this.lblColumns.AutoSize = true;
            this.lblColumns.ForeColor = System.Drawing.Color.White;
            this.lblColumns.Location = new System.Drawing.Point(340, 62);
            this.lblColumns.Name = "lblColumns";
            this.lblColumns.Size = new System.Drawing.Size(129, 31);
            this.lblColumns.TabIndex = 2;
            this.lblColumns.Text = "Columns:";
            // 
            // txtColumns
            // 
            this.txtColumns.Location = new System.Drawing.Point(475, 59);
            this.txtColumns.Name = "txtColumns";
            this.txtColumns.Size = new System.Drawing.Size(180, 38);
            this.txtColumns.TabIndex = 3;
            // 
            // txtRows
            // 
            this.txtRows.Location = new System.Drawing.Point(114, 59);
            this.txtRows.Name = "txtRows";
            this.txtRows.Size = new System.Drawing.Size(180, 38);
            this.txtRows.TabIndex = 4;
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.Color.LightYellow;
            this.btnGenerate.ForeColor = System.Drawing.Color.OliveDrab;
            this.btnGenerate.Location = new System.Drawing.Point(764, 47);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(180, 61);
            this.btnGenerate.TabIndex = 5;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = false;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // lblTools
            // 
            this.lblTools.AutoSize = true;
            this.lblTools.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTools.ForeColor = System.Drawing.Color.White;
            this.lblTools.Location = new System.Drawing.Point(155, 116);
            this.lblTools.Name = "lblTools";
            this.lblTools.Size = new System.Drawing.Size(133, 51);
            this.lblTools.TabIndex = 13;
            this.lblTools.Text = "Tools";
            // 
            // lblGreenBox
            // 
            this.lblGreenBox.AutoSize = true;
            this.lblGreenBox.ForeColor = System.Drawing.Color.White;
            this.lblGreenBox.Location = new System.Drawing.Point(17, 673);
            this.lblGreenBox.Name = "lblGreenBox";
            this.lblGreenBox.Size = new System.Drawing.Size(142, 31);
            this.lblGreenBox.TabIndex = 19;
            this.lblGreenBox.Text = "Green Box";
            this.lblGreenBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblRedBox
            // 
            this.lblRedBox.AutoSize = true;
            this.lblRedBox.ForeColor = System.Drawing.Color.White;
            this.lblRedBox.Location = new System.Drawing.Point(17, 575);
            this.lblRedBox.Name = "lblRedBox";
            this.lblRedBox.Size = new System.Drawing.Size(117, 31);
            this.lblRedBox.TabIndex = 18;
            this.lblRedBox.Text = "Red Box";
            this.lblRedBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblGreenDoor
            // 
            this.lblGreenDoor.AutoSize = true;
            this.lblGreenDoor.ForeColor = System.Drawing.Color.White;
            this.lblGreenDoor.Location = new System.Drawing.Point(17, 480);
            this.lblGreenDoor.Name = "lblGreenDoor";
            this.lblGreenDoor.Size = new System.Drawing.Size(155, 31);
            this.lblGreenDoor.TabIndex = 17;
            this.lblGreenDoor.Text = "Green Door";
            this.lblGreenDoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblRedDoor
            // 
            this.lblRedDoor.AutoSize = true;
            this.lblRedDoor.ForeColor = System.Drawing.Color.White;
            this.lblRedDoor.Location = new System.Drawing.Point(17, 381);
            this.lblRedDoor.Name = "lblRedDoor";
            this.lblRedDoor.Size = new System.Drawing.Size(130, 31);
            this.lblRedDoor.TabIndex = 16;
            this.lblRedDoor.Text = "Red Door";
            this.lblRedDoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblWall
            // 
            this.lblWall.AutoSize = true;
            this.lblWall.ForeColor = System.Drawing.Color.White;
            this.lblWall.Location = new System.Drawing.Point(17, 290);
            this.lblWall.Name = "lblWall";
            this.lblWall.Size = new System.Drawing.Size(66, 31);
            this.lblWall.TabIndex = 15;
            this.lblWall.Text = "Wall";
            this.lblWall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNone
            // 
            this.lblNone.AutoSize = true;
            this.lblNone.ForeColor = System.Drawing.Color.White;
            this.lblNone.Location = new System.Drawing.Point(17, 193);
            this.lblNone.Name = "lblNone";
            this.lblNone.Size = new System.Drawing.Size(79, 31);
            this.lblNone.TabIndex = 14;
            this.lblNone.Text = "None";
            this.lblNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBoxGB
            // 
            this.pictureBoxGB.BackColor = System.Drawing.Color.LightYellow;
            this.pictureBoxGB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxGB.Image = global::KYangQGame.Properties.Resources.gbox;
            this.pictureBoxGB.Location = new System.Drawing.Point(187, 649);
            this.pictureBoxGB.Name = "pictureBoxGB";
            this.pictureBoxGB.Size = new System.Drawing.Size(224, 77);
            this.pictureBoxGB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGB.TabIndex = 12;
            this.pictureBoxGB.TabStop = false;
            this.pictureBoxGB.Tag = "5";
            this.pictureBoxGB.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxWall
            // 
            this.pictureBoxWall.BackColor = System.Drawing.Color.LightYellow;
            this.pictureBoxWall.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxWall.Image = global::KYangQGame.Properties.Resources.brick_wall;
            this.pictureBoxWall.Location = new System.Drawing.Point(187, 265);
            this.pictureBoxWall.Name = "pictureBoxWall";
            this.pictureBoxWall.Size = new System.Drawing.Size(224, 77);
            this.pictureBoxWall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxWall.TabIndex = 11;
            this.pictureBoxWall.TabStop = false;
            this.pictureBoxWall.Tag = "1";
            this.pictureBoxWall.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxRB
            // 
            this.pictureBoxRB.BackColor = System.Drawing.Color.LightYellow;
            this.pictureBoxRB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxRB.Image = global::KYangQGame.Properties.Resources.rbox;
            this.pictureBoxRB.Location = new System.Drawing.Point(187, 553);
            this.pictureBoxRB.Name = "pictureBoxRB";
            this.pictureBoxRB.Size = new System.Drawing.Size(224, 77);
            this.pictureBoxRB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRB.TabIndex = 10;
            this.pictureBoxRB.TabStop = false;
            this.pictureBoxRB.Tag = "4";
            this.pictureBoxRB.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxGD
            // 
            this.pictureBoxGD.BackColor = System.Drawing.Color.LightYellow;
            this.pictureBoxGD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxGD.Image = global::KYangQGame.Properties.Resources.gdoor;
            this.pictureBoxGD.Location = new System.Drawing.Point(187, 457);
            this.pictureBoxGD.Name = "pictureBoxGD";
            this.pictureBoxGD.Size = new System.Drawing.Size(224, 77);
            this.pictureBoxGD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGD.TabIndex = 8;
            this.pictureBoxGD.TabStop = false;
            this.pictureBoxGD.Tag = "3";
            this.pictureBoxGD.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxRD
            // 
            this.pictureBoxRD.BackColor = System.Drawing.Color.LightYellow;
            this.pictureBoxRD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxRD.Image = global::KYangQGame.Properties.Resources.rdoor;
            this.pictureBoxRD.Location = new System.Drawing.Point(187, 361);
            this.pictureBoxRD.Name = "pictureBoxRD";
            this.pictureBoxRD.Size = new System.Drawing.Size(224, 77);
            this.pictureBoxRD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRD.TabIndex = 7;
            this.pictureBoxRD.TabStop = false;
            this.pictureBoxRD.Tag = "2";
            this.pictureBoxRD.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxNone
            // 
            this.pictureBoxNone.AccessibleDescription = "";
            this.pictureBoxNone.AccessibleName = "";
            this.pictureBoxNone.BackColor = System.Drawing.Color.LightYellow;
            this.pictureBoxNone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxNone.Image = global::KYangQGame.Properties.Resources.none_sign;
            this.pictureBoxNone.Location = new System.Drawing.Point(187, 170);
            this.pictureBoxNone.Name = "pictureBoxNone";
            this.pictureBoxNone.Size = new System.Drawing.Size(224, 77);
            this.pictureBoxNone.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxNone.TabIndex = 6;
            this.pictureBoxNone.TabStop = false;
            this.pictureBoxNone.Tag = "0";
            this.pictureBoxNone.Click += new System.EventHandler(this.OnClick);
            // 
            // DesignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            this.ClientSize = new System.Drawing.Size(967, 732);
            this.Controls.Add(this.lblGreenBox);
            this.Controls.Add(this.lblRedBox);
            this.Controls.Add(this.lblGreenDoor);
            this.Controls.Add(this.lblRedDoor);
            this.Controls.Add(this.lblWall);
            this.Controls.Add(this.lblNone);
            this.Controls.Add(this.lblTools);
            this.Controls.Add(this.pictureBoxGB);
            this.Controls.Add(this.pictureBoxWall);
            this.Controls.Add(this.pictureBoxRB);
            this.Controls.Add(this.pictureBoxGD);
            this.Controls.Add(this.pictureBoxRD);
            this.Controls.Add(this.pictureBoxNone);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.txtRows);
            this.Controls.Add(this.txtColumns);
            this.Controls.Add(this.lblColumns);
            this.Controls.Add(this.lblRows);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DesignForm";
            this.Text = "Q Game Design Panel";
            this.Load += new System.EventHandler(this.DesignForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNone)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.Label lblColumns;
        private System.Windows.Forms.TextBox txtColumns;
        private System.Windows.Forms.TextBox txtRows;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.PictureBox pictureBoxNone;
        private System.Windows.Forms.PictureBox pictureBoxRD;
        private System.Windows.Forms.PictureBox pictureBoxGD;
        private System.Windows.Forms.PictureBox pictureBoxRB;
        private System.Windows.Forms.PictureBox pictureBoxWall;
        private System.Windows.Forms.PictureBox pictureBoxGB;
        private System.Windows.Forms.Label lblTools;
        private System.Windows.Forms.Label lblGreenBox;
        private System.Windows.Forms.Label lblRedBox;
        private System.Windows.Forms.Label lblGreenDoor;
        private System.Windows.Forms.Label lblRedDoor;
        private System.Windows.Forms.Label lblWall;
        private System.Windows.Forms.Label lblNone;
    }
}