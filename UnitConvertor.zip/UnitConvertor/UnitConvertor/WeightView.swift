//
//  WeightView.swift
//  UnitConvertor
//
//  Created by Kate Yang on 2023-08-05.
//

import SwiftUI

struct WeightView: View {
    
    // Init weight inputs
    @State var tonne : Double = 0.0
    @State var kilogram : Double = 0.0
    @State var gram : Double = 0.0
    @State var milligram : Double = 0.0
    
    var body: some View {
        
        // Title of page
        Text("Weight Measurement")
            .font(.title)
            .bold()
            .padding(.vertical, 40)
        
        // Tonne conversion
        Text("Tonne (t)").bold()
        TextField("", value: $tonne, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.kilogram = self.tonne * 1000;
            self.gram = self.tonne * 1000 * 1000;
            self.milligram = self.tonne * 1000 * 1000 * 1000})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.pink))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
            
        // Kilogram conversion
        Text("Kilogram (kg)").bold()
        TextField("", value: $kilogram, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.tonne = self.kilogram / 1000;
            self.gram = self.kilogram * 1000;
            self.milligram = self.kilogram * 1000 * 1000})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.orange))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
        
        // Gram conversion
        Text("Gram (g)").bold()
        TextField("", value: $gram, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.tonne = self.gram / (1000 * 1000);
            self.kilogram = self.gram / 1000;
            self.milligram = self.gram * 1000})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.green))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
            
        // Milligram conversion
        Text("Milligram (mg)").bold()
        TextField("", value: $milligram, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.tonne = self.milligram / (1000 * 1000 * 1000);
            self.kilogram = self.milligram / (1000 * 1000);
            self.gram = self.milligram / 1000})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.blue))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
    }
}

// Default number format
extension NumberFormatter {
    static var twentyDecimal : NumberFormatter {
        let format = NumberFormatter()
        format.numberStyle = .decimal
        format.maximumFractionDigits = 20
        format.usesGroupingSeparator = false
        return format
    }
}

struct WeightView_Previews: PreviewProvider {
    static var previews: some View {
        WeightView()
    }
}
