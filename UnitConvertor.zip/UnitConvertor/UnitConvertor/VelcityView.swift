//
//  VelcityView.swift
//  UnitConvertor
//
//  Created by Kate Yang on 2023-08-05.
//

import SwiftUI

struct VelcityView: View {
    
    // Init velcity inputs
    @State var kilometer : Double = 0.0
    @State var mile : Double = 0.0
    
    var body: some View {
        
        // Title of page
        Text("Velcity Measurement")
            .font(.title)
            .bold()
            .padding(.vertical, 40)
        
        // Kilometer conversion
        Text("Kilometer (km) / hour").bold()
        TextField("", value: $kilometer, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.mile = self.kilometer * 0.6214;})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.pink))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
        
        // Mile conversion
        Text("Mile (mi) / hour").bold()
        TextField("", value: $mile, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.kilometer = self.mile / 0.6214;})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.orange))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
    }
}

struct VelcityView_Previews: PreviewProvider {
    static var previews: some View {
        VelcityView()
    }
}
