//
//  ContentView.swift
//  UnitConvertor
//
//  Created by Kate Yang on 2023-08-05.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView {
            VStack {
                // Link to temperature page
                NavigationLink (destination: TemperatureView(), label: {
                    Text("Temperature")
                }).padding(.vertical, 35)
                // Link to length page
                NavigationLink (destination: LengthView(), label: {
                    Text("Length")
                }).padding(.vertical, 35)
                // Link to weight page
                NavigationLink (destination: WeightView(), label: {
                    Text("Weight")
                }).padding(.vertical, 35)
                // Link to velcity page
                NavigationLink (destination: VelcityView(), label: {
                    Text("Velcity")
                }).padding(.vertical, 35)
            }
            .navigationTitle("Unit Convertor")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
