//
//  LengthView.swift
//  UnitConvertor
//
//  Created by Kate Yang on 2023-08-05.
//

import SwiftUI

struct LengthView: View {
    
    // Init length inputs
    @State var km : Double = 0.0
    @State var mi : Double = 0.0
    @State var foot : Double = 0.0
    @State var inch : Double = 0.0
    
    var body: some View {
        // Title of page
        Text("Length Measurement")
            .font(.title)
            .bold()
            .padding(.vertical, 40)
        
        // Kilometer conversion
        Text("Kilometer (km)").bold()
        TextField("", value: $km, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.mi = self.km * 0.6214;
            self.inch = self.km * 39370.08;
            self.foot = self.km * 3280.84})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.pink))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)

        // Mile conversion
        Text("Mile (mi)").bold()
        TextField("", value: $mi, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.km = self.mi / 0.6214;
            self.foot = self.mi * 5280;
            self.inch = self.mi * 63360})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.orange))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
        
        // Foot conversion
        Text("Foot (ft)").bold()
        TextField("", value: $foot, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.km = self.foot / 3280.84;
            self.mi = self.foot / 5280;
            self.inch = self.foot * 12})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.green))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
        
        // Inch conversion
        Text("Inch (in)").bold()
        TextField("", value: $inch, formatter: NumberFormatter.twentyDecimal, onEditingChanged: {(changed) in self.km = self.inch / 39370.08;
            self.mi = self.inch / 63360;
            self.foot = self.inch / 12})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.blue))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
    }
}


struct LengthView_Previews: PreviewProvider {
    static var previews: some View {
        LengthView()
    }
}
