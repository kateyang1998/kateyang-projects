//
//  TemperatureView.swift
//  UnitConvertor
//
//  Created by Kate Yang on 2023-08-05.
//

import SwiftUI

struct TemperatureView: View {
    
    // Init temprature inputs
    @State var celsius : Double = 0.0
    @State var fahrenheit : Double = 0.0
    @State var kelvin : Double = 0.0
    @State var rankine : Double = 0.0
    @State var reaumur : Double = 0.0
    
    var body: some View {
        
        // Title of page
        Text("Temprature Measurement")
            .font(.title)
            .bold()
            .padding(.vertical, 40)

        // Celsius conversion
        Text("Celsius (C)").bold()
        TextField("", value: $celsius, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.fahrenheit = self.celsius * 1.8 + 32;
            self.kelvin = self.celsius + 273.15;
            self.rankine = self.celsius * 1.8 + 32 + 459.67;
            self.reaumur = self.celsius * 0.8})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.pink))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
            
        // Fahrenheit conversion
        Text("Fahrenheit (F)").bold()
        TextField("", value: $fahrenheit, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.celsius = (self.fahrenheit - 32) / 1.8;
            self.kelvin = (self.fahrenheit + 459.67) / 1.8;
            self.rankine = self.fahrenheit + 459.67;
            self.reaumur = (self.fahrenheit - 32) / 2.25})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.orange))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
        
        // Kelvin conversion
        Text("Kelvin (K)").bold()
        TextField("", value: $kelvin, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.celsius = self.kelvin - 273.15;
            self.fahrenheit = self.kelvin * 1.8 - 459.67;
            self.rankine = self.kelvin * 1.8;
            self.reaumur = (self.kelvin - 273.15) * 0.8})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.green))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
            
        // Rankine conversion
        Text("Rankine (Ra)").bold()
        TextField("", value: $rankine, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.celsius = (self.rankine - 459.67 - 32) / 1.8;
            self.fahrenheit = self.rankine - 459.67;
            self.kelvin = self.rankine / 1.8;
            self.reaumur = (self.rankine - 459.67 - 32) / 2.25})
            .keyboardType(.numbersAndPunctuation)
            .foregroundColor(.white)
            .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.blue))
            .padding(.horizontal, 70)
            .multilineTextAlignment(.center)
        
        // Reaumur conversion
        VStack {
            Text("Reaumur (Re)").bold()
            TextField("", value: $reaumur, formatter: NumberFormatter.twoDecimal, onEditingChanged: {(changed) in self.celsius = self.reaumur * 1.25;
                self.fahrenheit = self.reaumur * 2.25 + 32;
                self.kelvin = self.reaumur * 1.25 + 273.15;
                self.rankine = self.reaumur * 2.25 + 32 + 459.67})
                .keyboardType(.numbersAndPunctuation)
                .foregroundColor(.white)
                .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.purple))
                .padding(.horizontal, 70)
                .multilineTextAlignment(.center)
        }
    }
}

// Default number format
extension NumberFormatter {
    static var twoDecimal : NumberFormatter {
        let format = NumberFormatter()
        format.numberStyle = .decimal
        format.maximumFractionDigits = 2
        format.usesGroupingSeparator = false
        return format
    }
}

struct TemperatureView_Previews: PreviewProvider {
    static var previews: some View {
        TemperatureView()
    }
}
