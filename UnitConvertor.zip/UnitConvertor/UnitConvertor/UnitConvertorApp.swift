//
//  UnitConvertorApp.swift
//  UnitConvertor
//
//  Created by Kate Yang on 2023-08-05.
//

import SwiftUI

@main
struct UnitConvertorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
