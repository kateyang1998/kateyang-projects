package club.admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import club.business.Book;
import club.data.BookIO;


@WebServlet(name = "KYMRAddBookServlet", urlPatterns = {"/KYMRAddBookServlet"})
public class KYMRAddBookServlet extends HttpServlet {
    
     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get input parameters
        String code = request.getParameter("code");
        String description = request.getParameter("description");
        String quantityStr = request.getParameter("quantity");

        // Default quantity to 0 if blank
        int quantity = 0;
        if (quantityStr != null && !quantityStr.isEmpty()) {
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                // Redirect to custom JSP error page if quantity is non-numeric
                response.sendRedirect("KYMRError.jsp");
                return;
            }
        }

        // Server-side input validation
        StringBuilder errorMessage = new StringBuilder();
        if (code == null || code.isEmpty()) {
            errorMessage.append("Book code is required.<br>");
        }
        if (description == null || description.length() < 3) {
            errorMessage.append("Description must have at least 3 characters.<br>");
        }
        if (quantity <= 0) {
            errorMessage.append("Quantity must be a positive number.<br>");
        }

        if (errorMessage.length() > 0) {
            // Store input values and error messages in request attributes
            request.setAttribute("book", new Book(code, description, quantity));
            request.setAttribute("errorMessage", errorMessage.toString());
            // Forward to the add book page
            request.getRequestDispatcher("KYMRAddBook.jsp").forward(request, response);
            return;
        }

        // If input fields are valid, add the book to the text file
        Book book = new Book(code, description, quantity);
        BookIO.insert(book, getServletContext().getRealPath("/WEB-INF/books.txt"));
        // Redirect to display books servlet
        response.sendRedirect("KYMRDisplayBooks");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }   
}
