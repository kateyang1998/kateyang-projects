package club.admin;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import club.business.Member;
import club.data.MemberDB;

public class KYMRMemberAdminController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/KYMRDisplayMembers.jsp";
        
        // get current action
        String action = request.getParameter("action");
        if(action == null) {
            action = "displayMembers"; // default action
        }
        
        if (action.equals("displayMembers")) {
            // get list of members
            ArrayList<Member> members = MemberDB.selectMembers();
            request.setAttribute("members", members);
        }
        else if (action.equals("addMember")) {
            url = "/KYMRAddMember.jsp";
            getServletContext().getRequestDispatcher(url).forward(request, response);
            return;
        }
        else if (action.equals("editMember")) {
            String emailAddress = request.getParameter("email");
            Member member = MemberDB.selectMember(emailAddress);
            
            if (member != null) {
                request.setAttribute("member", member);
                request.setAttribute("editMode", true); // Indicate editing mode
                url = "/KYMREditMember.jsp";
                getServletContext().getRequestDispatcher(url).forward(request, response);
                return;
            }
        }
        else if (action.equals("saveMember")) {
            url = saveMember(request, response);
            
            // get list of members
            ArrayList<Member> members = MemberDB.selectMembers();
            request.setAttribute("members", members);
        }
        else if (action.equals("removeMember")) {
            String emailAddress = request.getParameter("email");
            Member member = MemberDB.selectMember(emailAddress);
            
            if (member != null) {
                request.setAttribute("member", member);
                url = "/KYMRRemoveMember.jsp";
                getServletContext().getRequestDispatcher(url).forward(request, response);
                return;
            }
        }
        else if (action.equals("deleteMember")) {
            String emailAddress = request.getParameter("email");
            Member memberToDelete = MemberDB.selectMember(emailAddress); // Retrieve the Member object
            if (memberToDelete != null) {
                MemberDB.delete(memberToDelete); // Pass the Member object to the delete method
            }
            // Redirect to display members page
            url = "/KYMRDisplayMembers.jsp";
            
            // get list of members
            ArrayList<Member> members = MemberDB.selectMembers();
            request.setAttribute("members", members);
        }
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }
    
    private String saveMember(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url;
        
        // Retrieve form parameters
        String fullName = request.getParameter("fullName");
        String emailAddress = request.getParameter("emailAddress");
        String phoneNumber = request.getParameter("phoneNumber");
        String programName = request.getParameter("programName");
        int yearLevel = Integer.parseInt(request.getParameter("yearLevel"));
        
        // Create member objects
        Member member = new Member();
        member.setFullName(fullName);
        member.setEmailAddress(emailAddress);
        member.setPhoneNumber(phoneNumber);
        member.setProgramName(programName);
        member.setYearLevel(yearLevel);
        
        // Validate inputs
        if (member.isValid()) {
            if (MemberDB.emailExists(emailAddress)) {
                System.out.println("test line 104");
                // Update existing member
                MemberDB.update(member);
            } else {
                // Insert new member
                MemberDB.insert(member);
            }
            // Redirect to display members page
            url = "/KYMRDisplayMembers.jsp";
        } else {
            System.out.println("test line 113");
            
            // Invalid member, display error message
            request.setAttribute("errorMessage", "Invalid member details, please complete all fields.");
            if (request.getAttribute("editMode") != null && (boolean) request.getAttribute("editMode")) {
                System.out.println("test line 118");
                
                url = "/KYMREditMember.jsp"; // Stay on edit member page
            } 
            else {
                System.out.println("test line 123");
                
                url = "/KYMRAddMember.jsp"; // Redirect to add member page
            }
        }
        
        return url;
    }
}
