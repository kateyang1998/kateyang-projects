package club.admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import club.business.Book;
import club.data.BookIO;
import javax.servlet.http.HttpSession;

@WebServlet(name = "KYMRDisplayBooksServlet", urlPatterns = {"/KYMRDisplayBooksServlet"})
public class KYMRDisplayBooksServlet extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = getServletContext().getRealPath("/WEB-INF/books.txt");
        HttpSession session = request.getSession();
        ArrayList<Book> books = BookIO.getBooks(path); // Read all the books
        session.setAttribute("books", books); // Store books in the request object
        String url = "/KYMRDisplayBooks.jsp";
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
