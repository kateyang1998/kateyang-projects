package murach.business;

import java.io.Serializable;

public class KYMRUser implements Serializable {
    
    private String fullName;
    private String email;
    private String phone;
    private String itPrograms;
    private String yearLevel;

    public KYMRUser() {
        fullName = "";
        email = "";
        phone = "";
        itPrograms = "";
        yearLevel = "";
    }

    public KYMRUser(String fullName, String email, String phone, String itPrograms, String yearLevel) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.itPrograms = itPrograms;
        this.yearLevel = yearLevel;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
        public String getItPrograms() {
        return itPrograms;
    }

    public void setItPrograms(String itPrograms) {
        this.itPrograms = itPrograms;
    }

    public String getYearLevel() {
        return yearLevel;
    }

    public void setYearLevel(String yearLevel) {
        this.yearLevel = yearLevel;
    }

}
