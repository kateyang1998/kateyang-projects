package murach.email;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import murach.business.KYMRUser;

public class KYMREmailListServlet extends HttpServlet {
        
    @Override
    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {

        String url = "/KYMRIndex.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("join")) {
            url = "/KYMRRegister.jsp";    // the "join" page
        }
        else if (action.equals("add")) {                
            // get parameters from the request
            String fullName = request.getParameter("fullName");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String itPrograms = request.getParameter("itPrograms");
            String yearLevel = request.getParameter("yearLevel");

            // store data in User object and save User object in database
            KYMRUser user = new KYMRUser(fullName, email, phone, itPrograms, yearLevel);
            
            //validate the parameters
            String message;
            if (fullName == null || email == null || phone == null || itPrograms == null || yearLevel == null || fullName.isEmpty() || email.isEmpty() || phone.isEmpty() || itPrograms.isEmpty() || yearLevel.isEmpty()) {
                message = "Please fill out all required inputs.";
                url = "/KYMRRegister.jsp";
            }
            else {
                message = "";
                url = "/KYMRDisplayMember.jsp";
            }
            
            // set User object in request object and set URL
            request.setAttribute("user", user);
            request.setAttribute("errorMessage", message);
        }
        
        // forward request and response objects to specified URL
        getServletContext()
            .getRequestDispatcher(url)
            .forward(request, response);
    }    
    
    @Override
    protected void doGet(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        doPost(request, response);
    }    
}
