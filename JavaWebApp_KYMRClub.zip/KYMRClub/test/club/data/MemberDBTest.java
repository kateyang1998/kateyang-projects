package club.data;

import club.business.Member;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.h2.jdbcx.JdbcDataSource;
import javax.naming.Context;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import javax.naming.InitialContext;

public class MemberDBTest {
    private Member testMember = null;
    private static InitialContext ic;
    
    public MemberDBTest() {
    }
    
    @BeforeClass
    public static void setUpClass() throws NamingException {
        //Set up the initial context that will be used for JNDI lookups
        System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.naming.java.javaURLContextFactory");
        System.setProperty(Context.URL_PKG_PREFIXES, "org.apache.naming");
        ic = new InitialContext();
        
        //Create and bind a DataSource to the JNDI context
        ic.createSubcontext("java:");
        ic.createSubcontext("java:/comp");
        ic.createSubcontext("java:/comp/env");
        ic.createSubcontext("java:/comp/env/jdbc");
        
        //Initialize DataSource with H2 database for testing
        JdbcDataSource dataSource = new JdbcDataSource();
        dataSource.setURL("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        dataSource.setUser("myuser");
        dataSource.setPassword("mypass");
        
        ic.bind("java:/comp/env/jdbc/memberdb", dataSource);
        
        //Get the conection
        Connection conn = null;
        Statement stmt = null;
        
        try {
            conn = dataSource.getConnection();
            stmt = conn.createStatement();
            //Create the schema and tables
            stmt.execute("CREATE TABLE member (" +
            "  MemberID INT NOT NULL AUTO_INCREMENT, " +
            "  FullName VARCHAR(50), " +
            "  EmailAddress VARCHAR(50), " +
            "  PhoneNumber VARCHAR(20)," +
            "  ProgramName VARCHAR(20)," +
            "  YearLevel INT," +
            "  PRIMARY KEY (MemberID))");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if (stmt!=null) {
                try {
                    stmt.close();
                } 
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn!=null) {
                try {
                    conn.close();
                } 
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    @AfterClass
    public static void tearDownClass() throws NamingException {
        //Unbind the DataScource from the JNDI context
        ic.unbind("java:/comp/env/jdbc/memberdb");
        System.clearProperty(Context.INITIAL_CONTEXT_FACTORY);
        System.clearProperty(Context.URL_PKG_PREFIXES);
    }
    
    @Before
    public void setUp() {
        testMember = new Member();
        testMember.setFullName("Jennie Smith");
        testMember.setEmailAddress("jennie@test.com");
        testMember.setPhoneNumber("1234567890");
        testMember.setProgramName("CP");
        testMember.setYearLevel(1);
    }
    
    @After
    public void tearDown() {
        // Clean up the database after each test method
        if (MemberDB.emailExists(testMember.getEmailAddress())) {
            MemberDB.delete(testMember);
        }
    }

    /**
     * Test of insert method, of class MemberDB.
     */
    @Test
    public void testInsert() {
        System.out.println("insert");
        int expResult = 1;
        int result = MemberDB.insert(testMember);
        assertEquals(expResult, result);
    }

    /**
     * Test of update method, of class MemberDB.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");

        // Insert the member
        MemberDB.insert(testMember);

        // Modify the member's details
        testMember.setFullName("Jane Smith");
        testMember.setProgramName("CPA");

        int result = MemberDB.update(testMember);
        assertEquals(1, result);

        // Retrieve the member and verify the changes
        Member updatedMember = MemberDB.selectMember(testMember.getEmailAddress());
        assertEquals("Jane Smith", updatedMember.getFullName());
        assertEquals("CPA", updatedMember.getProgramName());
    }

    /**
     * Test of delete method, of class MemberDB.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        MemberDB.insert(testMember);
        int result = MemberDB.delete(testMember);
        assertEquals(1, result);
    }

    /**
     * Test of emailExists method, of class MemberDB.
     */
    @Test
    public void testEmailExists() {
        System.out.println("emailExists");
        MemberDB.insert(testMember);

        boolean exists = MemberDB.emailExists(testMember.getEmailAddress());
        assertTrue(exists);
    }

    /**
     * Test of selectMember method, of class MemberDB.
     */
    @Test
    public void testSelectMember() {
        System.out.println("selectMember");
        MemberDB.insert(testMember);
        Member selectedMember = MemberDB.selectMember(testMember.getEmailAddress());

        assertEquals(testMember.getEmailAddress(), selectedMember.getEmailAddress());
        assertEquals(testMember.getFullName(), selectedMember.getFullName());
        assertEquals(testMember.getPhoneNumber(), selectedMember.getPhoneNumber());
        assertEquals(testMember.getProgramName(), selectedMember.getProgramName());
        assertEquals(testMember.getYearLevel(), selectedMember.getYearLevel());
    }

    /**
     * Test of selectMembers method, of class MemberDB.
     */
    @Test
    public void testSelectMembers() {
        System.out.println("selectMembers");

        // Insert some test members
        Member alice = new Member();
        alice.setFullName("Alice Wilson");
        alice.setEmailAddress("alice@test.com");
        alice.setPhoneNumber("9891236784");
        alice.setProgramName("CAS");
        alice.setYearLevel(2);

        Member bob = new Member();
        bob.setFullName("Bob Jones");
        bob.setEmailAddress("bob@test.com");
        bob.setPhoneNumber("9967574321");
        bob.setProgramName("CAD");
        bob.setYearLevel(2);

        MemberDB.insert(alice);
        MemberDB.insert(bob);

        ArrayList<Member> result = MemberDB.selectMembers();
        assertNotNull(result);
        assertEquals(2, result.size());
    }
}