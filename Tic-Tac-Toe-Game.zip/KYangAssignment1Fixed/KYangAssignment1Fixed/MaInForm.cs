﻿/*
 * Project name: KYangAssignment1 - Tic-Tac-Toe Game
 * 
 * Purpose of project: to develope a Tic-Tac-Toe Game
 * 
 * Revision history: 
 *      created by Kate Yang, Sep 20 2023
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KYangAssignment1Fixed
{
    public partial class MaInForm : Form
    {
        // Declare images for the game
        Image x = KYangAssignment1Fixed.Properties.Resources.X;
        Image o = KYangAssignment1Fixed.Properties.Resources.O;

        // Declare the player turn - true is X
        bool playerTurn = true;

        // Declare the winner possibilities
        enum Winner { None, PlayerX, PlayerO, Tie };
        Winner winner;

        // Function to start a new game
        void OnNewGame()
        {
            // Include all pictures in an array
            PictureBox[] pictures =
            {
                pictureBoxSign1,
                pictureBoxSign2,
                pictureBoxSign3,
                pictureBoxSign4,
                pictureBoxSign5,
                pictureBoxSign6,
                pictureBoxSign7,
                pictureBoxSign8,
                pictureBoxSign9
            };

            // Clear all the pictures from picture boxes on new game
            foreach (PictureBox pictureBox in pictures)
            {
                pictureBox.Image = null;
            }

            // Initialize the game to start with X, and no one is winner
            playerTurn = true;
            winner = Winner.None;
        }

        // Function to check winner
        Winner GetWinner()
        {
            PictureBox[] winningResults =
            {
                // Check rows
                pictureBoxSign1, pictureBoxSign2, pictureBoxSign3,
                pictureBoxSign4, pictureBoxSign5, pictureBoxSign6,
                pictureBoxSign7, pictureBoxSign8, pictureBoxSign9,
                
                // Check columns
                pictureBoxSign1, pictureBoxSign4, pictureBoxSign7,
                pictureBoxSign2, pictureBoxSign5, pictureBoxSign8,
                pictureBoxSign3, pictureBoxSign6, pictureBoxSign9,

                // Check diagnals
                pictureBoxSign1, pictureBoxSign5, pictureBoxSign9,
                pictureBoxSign3, pictureBoxSign5, pictureBoxSign7,
            };

            for (int i = 0; i < winningResults.Length; i += 3) // To check 3 pictures together
            {
                if (winningResults[i].Image != null)
                {
                    if (winningResults[i].Image == winningResults[i + 1].Image && winningResults[i].Image == winningResults[i + 2].Image)
                    {
                        if (winningResults[i].Image == x)
                        {
                            MessageBox.Show("Player X wins!", "Winner", MessageBoxButtons.OK); // Display message for winner X
                            OnNewGame(); // Restart the game automatically
                            return Winner.PlayerX;
                        }
                        else
                        {
                            MessageBox.Show("Player O wins!", "Winner", MessageBoxButtons.OK); // Display message for winner O
                            OnNewGame(); // Restart the game automatically
                            return Winner.PlayerO;
                        }
                    }
                }
            }

            // Check if there is any empty picture box
            PictureBox[] pictures =
            {
                pictureBoxSign1,
                pictureBoxSign2,
                pictureBoxSign3,
                pictureBoxSign4,
                pictureBoxSign5,
                pictureBoxSign6,
                pictureBoxSign7,
                pictureBoxSign8,
                pictureBoxSign9
            };

            foreach (PictureBox pictureBox in pictures)
            {
                if (pictureBox.Image == null)
                {
                    return Winner.None;
                }
            }

            MessageBox.Show("No winner this time!", "Winner", MessageBoxButtons.OK); // Display message when there is no winner
            OnNewGame(); // Restart the game automatically
            return Winner.Tie;
        }

        public MaInForm()
        {
            InitializeComponent();
        }

        // Initial setting of the application
        private void MaInForm_Load(object sender, EventArgs e)
        {
            OnNewGame();
        }

        // Enabled to click the picture boxes
        private void OnClick(object sender, EventArgs e)
        {
            PictureBox pictureBox = sender as PictureBox;

            // Unabled the picture box when it already had image displaying
            if (pictureBox.Image != null)
            {
                return;
            }

            if (playerTurn)
            {
                pictureBox.Image = x;
            }
            else
            {
                pictureBox.Image = o;
            }

            // Check winner
            winner = GetWinner();

            if (winner == Winner.None)
            {
                // Change player turn
                if (playerTurn)
                {
                    playerTurn = false;
                }
                else
                {
                    playerTurn = true;
                }
            }
        }

        // New Game button
        private void btnNewGame_Click(object sender, EventArgs e)
        {
            // Display the confirm message to players
            var option = MessageBox.Show("Do you want to start a new game?", "New Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Start a new game when players choose "yes"
            if (option == DialogResult.Yes)
            {
                OnNewGame();
            }
        }

        // Exit button
        private void btnExit_Click(object sender, EventArgs e)
        {
            // Display the confirm message to players
            var option = MessageBox.Show("Do you want to exit the game?", "Exit Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Close the form when players choose "yes"
            if (option == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
