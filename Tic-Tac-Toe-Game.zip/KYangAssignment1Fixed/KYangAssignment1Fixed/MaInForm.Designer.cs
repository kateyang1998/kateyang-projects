﻿namespace KYangAssignment1Fixed
{
    partial class MaInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign9 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSign7 = new System.Windows.Forms.PictureBox();
            this.lblPlayerX = new System.Windows.Forms.Label();
            this.pictureBoxX = new System.Windows.Forms.PictureBox();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.lblPlayerO = new System.Windows.Forms.Label();
            this.pictureBoxO = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxO)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.Yellow;
            this.lblTitle.Location = new System.Drawing.Point(19, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(648, 119);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Tic-Tac-Toe";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(39, 131);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 600);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBoxSign1
            // 
            this.pictureBoxSign1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign1.Location = new System.Drawing.Point(58, 154);
            this.pictureBoxSign1.Name = "pictureBoxSign1";
            this.pictureBoxSign1.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign1.TabIndex = 2;
            this.pictureBoxSign1.TabStop = false;
            this.pictureBoxSign1.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign2
            // 
            this.pictureBoxSign2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign2.Location = new System.Drawing.Point(249, 154);
            this.pictureBoxSign2.Name = "pictureBoxSign2";
            this.pictureBoxSign2.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign2.TabIndex = 3;
            this.pictureBoxSign2.TabStop = false;
            this.pictureBoxSign2.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign3
            // 
            this.pictureBoxSign3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign3.Location = new System.Drawing.Point(441, 154);
            this.pictureBoxSign3.Name = "pictureBoxSign3";
            this.pictureBoxSign3.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign3.TabIndex = 4;
            this.pictureBoxSign3.TabStop = false;
            this.pictureBoxSign3.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign6
            // 
            this.pictureBoxSign6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign6.Location = new System.Drawing.Point(441, 343);
            this.pictureBoxSign6.Name = "pictureBoxSign6";
            this.pictureBoxSign6.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign6.TabIndex = 7;
            this.pictureBoxSign6.TabStop = false;
            this.pictureBoxSign6.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign5
            // 
            this.pictureBoxSign5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign5.Location = new System.Drawing.Point(249, 343);
            this.pictureBoxSign5.Name = "pictureBoxSign5";
            this.pictureBoxSign5.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign5.TabIndex = 6;
            this.pictureBoxSign5.TabStop = false;
            this.pictureBoxSign5.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign4
            // 
            this.pictureBoxSign4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign4.Location = new System.Drawing.Point(58, 343);
            this.pictureBoxSign4.Name = "pictureBoxSign4";
            this.pictureBoxSign4.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign4.TabIndex = 5;
            this.pictureBoxSign4.TabStop = false;
            this.pictureBoxSign4.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign9
            // 
            this.pictureBoxSign9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign9.Location = new System.Drawing.Point(441, 533);
            this.pictureBoxSign9.Name = "pictureBoxSign9";
            this.pictureBoxSign9.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign9.TabIndex = 10;
            this.pictureBoxSign9.TabStop = false;
            this.pictureBoxSign9.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign8
            // 
            this.pictureBoxSign8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign8.Location = new System.Drawing.Point(249, 533);
            this.pictureBoxSign8.Name = "pictureBoxSign8";
            this.pictureBoxSign8.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign8.TabIndex = 9;
            this.pictureBoxSign8.TabStop = false;
            this.pictureBoxSign8.Click += new System.EventHandler(this.OnClick);
            // 
            // pictureBoxSign7
            // 
            this.pictureBoxSign7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBoxSign7.Location = new System.Drawing.Point(58, 533);
            this.pictureBoxSign7.Name = "pictureBoxSign7";
            this.pictureBoxSign7.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxSign7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSign7.TabIndex = 8;
            this.pictureBoxSign7.TabStop = false;
            this.pictureBoxSign7.Click += new System.EventHandler(this.OnClick);
            // 
            // lblPlayerX
            // 
            this.lblPlayerX.AutoSize = true;
            this.lblPlayerX.Font = new System.Drawing.Font("Showcard Gothic", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerX.Location = new System.Drawing.Point(701, 187);
            this.lblPlayerX.Name = "lblPlayerX";
            this.lblPlayerX.Size = new System.Drawing.Size(194, 46);
            this.lblPlayerX.TabIndex = 11;
            this.lblPlayerX.Text = "Player X";
            // 
            // pictureBoxX
            // 
            this.pictureBoxX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxX.Image = global::KYangAssignment1Fixed.Properties.Resources.X;
            this.pictureBoxX.Location = new System.Drawing.Point(709, 236);
            this.pictureBoxX.Name = "pictureBoxX";
            this.pictureBoxX.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxX.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxX.TabIndex = 12;
            this.pictureBoxX.TabStop = false;
            // 
            // btnNewGame
            // 
            this.btnNewGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNewGame.Font = new System.Drawing.Font("Showcard Gothic", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewGame.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnNewGame.Location = new System.Drawing.Point(709, 533);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(424, 70);
            this.btnNewGame.TabIndex = 13;
            this.btnNewGame.Text = "New Game";
            this.btnNewGame.UseVisualStyleBackColor = false;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // lblPlayerO
            // 
            this.lblPlayerO.AutoSize = true;
            this.lblPlayerO.Font = new System.Drawing.Font("Showcard Gothic", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerO.Location = new System.Drawing.Point(945, 187);
            this.lblPlayerO.Name = "lblPlayerO";
            this.lblPlayerO.Size = new System.Drawing.Size(193, 46);
            this.lblPlayerO.TabIndex = 14;
            this.lblPlayerO.Text = "Player O";
            // 
            // pictureBoxO
            // 
            this.pictureBoxO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxO.Image = global::KYangAssignment1Fixed.Properties.Resources.O;
            this.pictureBoxO.Location = new System.Drawing.Point(953, 236);
            this.pictureBoxO.Name = "pictureBoxO";
            this.pictureBoxO.Size = new System.Drawing.Size(180, 180);
            this.pictureBoxO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxO.TabIndex = 15;
            this.pictureBoxO.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.Font = new System.Drawing.Font("Showcard Gothic", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(709, 628);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(424, 70);
            this.btnExit.TabIndex = 16;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MaInForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(1182, 785);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pictureBoxO);
            this.Controls.Add(this.lblPlayerO);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.pictureBoxX);
            this.Controls.Add(this.lblPlayerX);
            this.Controls.Add(this.pictureBoxSign9);
            this.Controls.Add(this.pictureBoxSign8);
            this.Controls.Add(this.pictureBoxSign7);
            this.Controls.Add(this.pictureBoxSign6);
            this.Controls.Add(this.pictureBoxSign5);
            this.Controls.Add(this.pictureBoxSign4);
            this.Controls.Add(this.pictureBoxSign3);
            this.Controls.Add(this.pictureBoxSign2);
            this.Controls.Add(this.pictureBoxSign1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MaInForm";
            this.Text = "Tic-Tac-Toe";
            this.Load += new System.EventHandler(this.MaInForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSign7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxO)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBoxSign1;
        private System.Windows.Forms.PictureBox pictureBoxSign2;
        private System.Windows.Forms.PictureBox pictureBoxSign3;
        private System.Windows.Forms.PictureBox pictureBoxSign6;
        private System.Windows.Forms.PictureBox pictureBoxSign5;
        private System.Windows.Forms.PictureBox pictureBoxSign4;
        private System.Windows.Forms.PictureBox pictureBoxSign9;
        private System.Windows.Forms.PictureBox pictureBoxSign8;
        private System.Windows.Forms.PictureBox pictureBoxSign7;
        private System.Windows.Forms.Label lblPlayerX;
        private System.Windows.Forms.PictureBox pictureBoxX;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Label lblPlayerO;
        private System.Windows.Forms.PictureBox pictureBoxO;
        private System.Windows.Forms.Button btnExit;
    }
}

