/*
 * Project Name: YangKateTwo_Alarm Clock
 * 
 * Purpose of Project: to create an alarm clock
 * 
 * Revision History:
 *      created by Kate Yang, Jun 1 2023 - Section 4
 */

namespace YangKateTwo
{
    public partial class DigitalAlarm : Form
    {
        System.Timers.Timer timer;

        public DigitalAlarm()
        {
            InitializeComponent();
        }

        private void DigitalAlarm_Load(object sender, EventArgs e)
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000;
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            timer.Start();
            alarmStatusLabel.Text = "IS ON";
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            timer.Stop();
            alarmPicture.Visible = false;
            alarmStatusLabel.Text = "IS OFF";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            DateTime alarmTime = alarmTimePIcker.Value;
            if (currentTime.Hour == alarmTime.Hour && currentTime.Minute == alarmTime.Minute && currentTime.Second == alarmTime.Second)
            {
                timer.Stop();
                alarmPicture.Visible = true;
                alarmStatusLabel.Text = "Now is the time!";
            }

            currentTimeHourAndMin.Text = DateTime.Now.ToString("h:mm");
            currentSecond.Text = DateTime.Now.Second.ToString();
            currentAMorPM.Text = DateTime.Now.ToString("tt");
            dateTextBox.Text = DateTime.Today.ToString("dd-MMM-yyyy");
            dayOfTheWeekTextBox.Text = DateTime.Now.DayOfWeek.ToString();
        }
    }
}