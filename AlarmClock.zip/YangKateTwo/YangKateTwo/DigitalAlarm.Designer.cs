﻿namespace YangKateTwo
{
    partial class DigitalAlarm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DigitalAlarm));
            this.alarmTimePIcker = new System.Windows.Forms.DateTimePicker();
            this.alarmTimePickerLabel = new System.Windows.Forms.Label();
            this.alarmStatusLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.dayOfWeekLabel = new System.Windows.Forms.Label();
            this.dateTextBox = new System.Windows.Forms.TextBox();
            this.dayOfTheWeekTextBox = new System.Windows.Forms.TextBox();
            this.startButton = new System.Windows.Forms.Button();
            this.stopButton = new System.Windows.Forms.Button();
            this.currentTimeHourAndMin = new System.Windows.Forms.TextBox();
            this.alarmPicture = new System.Windows.Forms.PictureBox();
            this.currentSecond = new System.Windows.Forms.TextBox();
            this.currentAMorPM = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.alarmPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // alarmTimePIcker
            // 
            this.alarmTimePIcker.CalendarFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.alarmTimePIcker.Font = new System.Drawing.Font("Cooper Black", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.alarmTimePIcker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.alarmTimePIcker.Location = new System.Drawing.Point(127, 357);
            this.alarmTimePIcker.Name = "alarmTimePIcker";
            this.alarmTimePIcker.Size = new System.Drawing.Size(404, 68);
            this.alarmTimePIcker.TabIndex = 0;
            // 
            // alarmTimePickerLabel
            // 
            this.alarmTimePickerLabel.AutoSize = true;
            this.alarmTimePickerLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.alarmTimePickerLabel.Location = new System.Drawing.Point(127, 306);
            this.alarmTimePickerLabel.Name = "alarmTimePickerLabel";
            this.alarmTimePickerLabel.Size = new System.Drawing.Size(152, 37);
            this.alarmTimePickerLabel.TabIndex = 1;
            this.alarmTimePickerLabel.Text = "Alarm Time";
            // 
            // alarmStatusLabel
            // 
            this.alarmStatusLabel.AutoSize = true;
            this.alarmStatusLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.alarmStatusLabel.Location = new System.Drawing.Point(127, 549);
            this.alarmStatusLabel.Name = "alarmStatusLabel";
            this.alarmStatusLabel.Size = new System.Drawing.Size(211, 45);
            this.alarmStatusLabel.TabIndex = 2;
            this.alarmStatusLabel.Text = "Alarm Status";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dateLabel.Location = new System.Drawing.Point(127, 625);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(73, 37);
            this.dateLabel.TabIndex = 3;
            this.dateLabel.Text = "Date";
            // 
            // dayOfWeekLabel
            // 
            this.dayOfWeekLabel.AutoSize = true;
            this.dayOfWeekLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dayOfWeekLabel.Location = new System.Drawing.Point(593, 625);
            this.dayOfWeekLabel.Name = "dayOfWeekLabel";
            this.dayOfWeekLabel.Size = new System.Drawing.Size(211, 37);
            this.dayOfWeekLabel.TabIndex = 4;
            this.dayOfWeekLabel.Text = "Day of the Week";
            // 
            // dateTextBox
            // 
            this.dateTextBox.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.dateTextBox.Location = new System.Drawing.Point(127, 685);
            this.dateTextBox.Name = "dateTextBox";
            this.dateTextBox.Size = new System.Drawing.Size(404, 57);
            this.dateTextBox.TabIndex = 5;
            this.dateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dayOfTheWeekTextBox
            // 
            this.dayOfTheWeekTextBox.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.dayOfTheWeekTextBox.Location = new System.Drawing.Point(593, 685);
            this.dayOfTheWeekTextBox.Name = "dayOfTheWeekTextBox";
            this.dayOfTheWeekTextBox.Size = new System.Drawing.Size(404, 57);
            this.dayOfTheWeekTextBox.TabIndex = 6;
            this.dayOfTheWeekTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.startButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.startButton.Location = new System.Drawing.Point(127, 454);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(162, 46);
            this.startButton.TabIndex = 7;
            this.startButton.Text = "Alarm ON";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.stopButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.stopButton.Location = new System.Drawing.Point(369, 454);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(162, 46);
            this.stopButton.TabIndex = 8;
            this.stopButton.Text = "AlarmOFF";
            this.stopButton.UseVisualStyleBackColor = false;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // currentTimeHourAndMin
            // 
            this.currentTimeHourAndMin.Font = new System.Drawing.Font("Segoe UI", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.currentTimeHourAndMin.Location = new System.Drawing.Point(127, 82);
            this.currentTimeHourAndMin.Name = "currentTimeHourAndMin";
            this.currentTimeHourAndMin.Size = new System.Drawing.Size(728, 178);
            this.currentTimeHourAndMin.TabIndex = 9;
            this.currentTimeHourAndMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // alarmPicture
            // 
            this.alarmPicture.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.alarmPicture.Image = ((System.Drawing.Image)(resources.GetObject("alarmPicture.Image")));
            this.alarmPicture.Location = new System.Drawing.Point(604, 306);
            this.alarmPicture.Name = "alarmPicture";
            this.alarmPicture.Size = new System.Drawing.Size(393, 288);
            this.alarmPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.alarmPicture.TabIndex = 10;
            this.alarmPicture.TabStop = false;
            this.alarmPicture.Visible = false;
            // 
            // currentSecond
            // 
            this.currentSecond.Font = new System.Drawing.Font("Segoe UI Black", 19.875F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.currentSecond.Location = new System.Drawing.Point(861, 82);
            this.currentSecond.Name = "currentSecond";
            this.currentSecond.Size = new System.Drawing.Size(136, 78);
            this.currentSecond.TabIndex = 11;
            // 
            // currentAMorPM
            // 
            this.currentAMorPM.Font = new System.Drawing.Font("Segoe UI Black", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.currentAMorPM.Location = new System.Drawing.Point(861, 189);
            this.currentAMorPM.Name = "currentAMorPM";
            this.currentAMorPM.Size = new System.Drawing.Size(136, 71);
            this.currentAMorPM.TabIndex = 12;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // DigitalAlarm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(18F, 45F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1127, 879);
            this.Controls.Add(this.currentAMorPM);
            this.Controls.Add(this.currentSecond);
            this.Controls.Add(this.alarmPicture);
            this.Controls.Add(this.currentTimeHourAndMin);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.dayOfTheWeekTextBox);
            this.Controls.Add(this.dateTextBox);
            this.Controls.Add(this.dayOfWeekLabel);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.alarmStatusLabel);
            this.Controls.Add(this.alarmTimePickerLabel);
            this.Controls.Add(this.alarmTimePIcker);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DigitalAlarm";
            this.Text = "Digital Alarm";
            this.Load += new System.EventHandler(this.DigitalAlarm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.alarmPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DateTimePicker alarmTimePIcker;
        private Label alarmTimePickerLabel;
        private Label alarmStatusLabel;
        private Label dateLabel;
        private Label dayOfWeekLabel;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button startButton;
        private Button stopButton;
        private TextBox currentTimeHourAndMin;
        private PictureBox alarmPicture;
        private TextBox currentSecond;
        private TextBox currentAMorPM;
        private TextBox dateTextBox;
        private TextBox dayOfTheWeekTextBox;
        private System.Windows.Forms.Timer timer1;
    }
}